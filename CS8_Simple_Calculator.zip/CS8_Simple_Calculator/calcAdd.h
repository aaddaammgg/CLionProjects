//
// Created by Adam G. on 1/16/2022.
//

#ifndef CS8_SIMPLE_CALCULATOR_CALCADD_H
#define CS8_SIMPLE_CALCULATOR_CALCADD_H

#include "calcBase.h"
#include "calcHistory.h"

class calcAdd : public calcBase {
private:
public:
    calcAdd();
};


#endif //CS8_SIMPLE_CALCULATOR_CALCADD_H
