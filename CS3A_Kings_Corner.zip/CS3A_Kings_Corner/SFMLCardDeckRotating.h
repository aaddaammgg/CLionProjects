//
// Created by NAMEHERE on 11/25/2021.
//

#ifndef CS3A_KINGS_CORNER_SFMLCARDDECKROTATING_H
#define CS3A_KINGS_CORNER_SFMLCARDDECKROTATING_H

#include <SFML/Graphics.hpp>
#include "SFMLCard.h"

class SFMLCardDeckRotating : public sf::Drawable {
private:
    std::vector<SFMLCard> allCards;
public:

};


#endif //CS3A_KINGS_CORNER_SFMLCARDDECKROTATING_H
