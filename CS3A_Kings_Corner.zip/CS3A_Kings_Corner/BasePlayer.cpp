//
// Created by Adam G. on 12/7/2021.
//

#include "BasePlayer.h"

BasePlayer::BasePlayer() {

}

CardPile &BasePlayer::getCardPile() {
    return cardPile;
}
